# NC File Converter License

Copyright (c) 2025 Lasercomb GmbH

## Terms of Use

1. **Redistribution**: This software may be freely distributed in its original, unmodified form.

2. **No Modification**: Modification, adaptation, or derivative works of the software are not permitted without explicit written permission from the copyright holder.

3. **Attribution**: Redistribution must retain this license notice, the list of conditions, and the following disclaimer.

4. **No Warranty**: The software is provided "as is", without warranty of any kind, express or implied, including but not limited to the warranties of merchantability, fitness for a particular purpose, and noninfringement. In no event shall the authors or copyright holders be liable for any claim, damages, or other liability, whether in an action of contract, tort or otherwise, arising from, out of, or in connection with the software or the use or other dealings in the software.

5. **No Endorsement**: The name of the copyright holder may not be used to endorse or promote products derived from this software without specific prior written permission.

## Additional Permissions

For inquiries about obtaining permission to modify or create derivative works, please contact Lasercomb GmbH.

---

By using this software, you agree to abide by these terms.
